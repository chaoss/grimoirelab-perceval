.. _reference.entry.publisher:

:py:attr:`entries[i].publisher`
===============================

The publisher of the entry.


.. rubric:: Comes from

* /rss/item/dc:publisher
* /rss/item/itunes:owner
* /rdf:RDF/rdf:item/dc:publisher


.. seealso::

    * :ref:`reference.entry.publisher_detail`
