# Makes Sphinx create a <link> to feedparser.css in the HTML output
def setup(app):
    app.add_stylesheet('feedparser.css')
